package org.example.service;

import org.example.dao.VehiculoDAO;
import org.example.dao.VehiculoDAOImpl;
import org.example.entity.VehiculoEntity;

import java.sql.SQLException;
import java.util.List;

public class VehiculoService {

    private final VehiculoDAO vehiculoDAO = new VehiculoDAOImpl();

    public List<VehiculoEntity> checkVehiculos(List<String> matriculas) {

        return vehiculoDAO.selectVehiculo(matriculas);
    }

    public void eliminateVehiculo(List<VehiculoEntity> vehiculos) throws SQLException {
        vehiculoDAO.deleteVehiculo(vehiculos);
    }
}
