package org.example.dao;

import org.example.entity.VehiculoEntity;

import java.sql.SQLException;
import java.util.List;

public interface VehiculoDAO {

    List<VehiculoEntity> selectVehiculo(List<String> matriculas);

    void deleteVehiculo(List<VehiculoEntity> vehiculos) throws SQLException;
}
