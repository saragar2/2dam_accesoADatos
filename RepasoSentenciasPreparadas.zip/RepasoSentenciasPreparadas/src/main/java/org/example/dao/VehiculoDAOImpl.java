package org.example.dao;

import org.example.entity.VehiculoEntity;
import org.example.pool.ConnectionPool;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VehiculoDAOImpl implements VehiculoDAO {


    @Override
    public List<VehiculoEntity> selectVehiculo(List<String> matriculas) {

        List<VehiculoEntity> vehiculos = new ArrayList<>();

        String sql = "SELECT * " +
                "FROM vehiculo " +
                "WHERE matricula = ? " +
                "AND (marca = 'Opel' OR marca = 'Peugeot' OR marca = 'Audi')";

        try (Connection conn = ConnectionPool.getDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            for (String m : matriculas) {
                ps.setString(1, m);

                try (ResultSet rs = ps.executeQuery()) {

                    if (rs.next()) {
                        VehiculoEntity vehiculoEntity = new VehiculoEntity();
                        vehiculoEntity.setIdVehiculo(rs.getInt(1));
                        vehiculoEntity.setMatricula(rs.getString(2));
                        vehiculoEntity.setBastidor(rs.getString(3));
                        vehiculoEntity.setMarca(rs.getString(4));
                        vehiculoEntity.setModelo(rs.getString(5));
                        vehiculoEntity.setColor(rs.getString(6));
                        vehiculoEntity.setAnio(rs.getInt(7));
                        vehiculoEntity.setIdCategoria(rs.getInt(8));
                        vehiculoEntity.setIdSucursal(rs.getInt(9));
                        vehiculoEntity.setIdComb(rs.getInt(10));
                        vehiculos.add(vehiculoEntity);
                    }
                }
            }


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return vehiculos;
    }


    @Override
    public void deleteVehiculo(List<VehiculoEntity> vehiculos) throws SQLException {

        String sql = "DELETE FROM vehiculo " +
                     "WHERE id_vehiculo = ?";

        try (Connection conn = ConnectionPool.getDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            conn.setAutoCommit(false);

            try {
                for (VehiculoEntity vE : vehiculos) {
                    ps.setInt(1, vE.getIdVehiculo());
                    ps.addBatch();
                }

                ps.executeBatch();
                conn.commit();

            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        }

    }
}
