package org.example;

import org.example.entity.VehiculoEntity;
import org.example.service.VehiculoService;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        try (Scanner sc = new Scanner(System.in)) {
            VehiculoService vehiculoService = new VehiculoService();
            List<VehiculoEntity> vehiculos = new ArrayList<>();

            List<String> matriculas = new ArrayList<>();

            System.out.println("Bienvenido al programa para eliminar vehículos por matrícula." +
                    "Introduce los códigos de barra por la consola: (Para finalizar teclee la letra F)");

            String keyboard = sc.nextLine().trim();

            while (!("F".equalsIgnoreCase(keyboard))) {
                matriculas.add(keyboard);
                keyboard = sc.nextLine();
            }

            vehiculos = vehiculoService.checkVehiculos(matriculas);
            int vehiculoIndex = 1;
            if (!vehiculos.isEmpty()) {
                for (VehiculoEntity vE : vehiculos) {


                    System.out.println("Producto seleccionado: Vehiculo" + vehiculoIndex +
                            " (" + vE.getMatricula() + ") " +
                            vE.getMarca() + " " + vE.getModelo() + " " + vE.getIdVehiculo() +
                            "\n=============================================================");
                    vehiculoIndex++;
                }

                System.out.println("¿Desea eliminar estos productos? Y/N");
                keyboard = sc.nextLine().trim();
                if ("Y".equalsIgnoreCase(keyboard)) {
                    vehiculoService.eliminateVehiculo(vehiculos);
                    System.out.println("Todo correcto.");

                } else if ("N".equalsIgnoreCase(keyboard)) {
                    System.out.println("Bye bye.");

                } else {
                    System.out.println("Aprende a leer y elige bien. Me cierro y me voy.");
                }


            } else {
                System.out.println("No hay coincidencias.");
            }
        } catch (SQLException e) {
            System.out.println("No se ha podido realizar el borrado.");
            throw new RuntimeException(e);
        }
    }
}